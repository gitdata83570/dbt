#include<stdio.h>
int main()
{
      char a[5]="abcde",arr1[5],arr2[5];
      int count=0,i,j;
      
      printf("Entered string is:");
        
        for(int i=0;i<5;i++)

            printf("%c",a[i]);

    printf("\nReverse string is:");
       
        for(int j=sizeof(a-1);j>=0;j--)
            printf("%c",a[j]);       

    printf("\nLength of string is:");
       
        for(int i=0;i<5;i++)
            count++; 

        printf("%d",count);

   


    return 0;
}