#include<stdio.h>
int main()
{
    int n1;
    printf("value before pointer: ");
    scanf("%d",&n1);
    int N1=accept_Num(&n1);
    return 0;

}
int accept_Num(int *p)
{
    p=20;
    printf("Value after pointer is: %d\n",p);

}