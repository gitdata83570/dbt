#include<stdio.h>
void accept(int arr[2][2]);
void disp(int arr[2][2]);


int main(void)
{
    int a[2][2],b[2][2],c[2][2];
    int i,j;

    printf("\n Please enter first array elements :\n");
    accept(a);
    printf("\n Please enter second array elements :\n");
    accept(b);
    printf("\n First Array Elements \n");
    disp(a);
    printf("\n Second Array Elements \n");
    disp(b);
    for(i=0;i<2;i++)  
    {
        for(j=0;j<2;j++) 
        {
            c[i][j]=a[i][j]+b[i][j];
        }
    }
    printf("\n Addition of two arrays is: \n");
    disp(c);


   return 0;
}
void accept(int arr[2][2])
{
    int i,j;
    for(i=0;i<2;i++)  
    {
        for(j=0;j<2;j++) 
        {
            scanf("%d",&arr[i][j]);
        }
    }
}

void disp(int arr[2][2])
{
    int i,j;
    for(i=0;i<2;i++)  
    {
        for(j=0;j<2;j++) 
        {
            printf("%d \t",arr[i][j]);
        }
        printf("\n");
    }
}