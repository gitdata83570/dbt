/*#include<stdio.h>
int main()
{
    char arr[5]="abcde";
    int k;

        printf("Given string is: ");
    for(int i=0;i<5;i++)
        printf("%c ",arr[i]);

        printf("\nReverse of string is: ");
    for(int j=sizeof(arr-1);j>=0;j--)
        printf("%c ",arr[j]);  

    for(int k=0;k!='\0';k++)
      { 
         printf("%d",arr[k]);
      } 
        printf("\nlength of string is:%d ",k);


    return 0;
}*/
#include<stdio.h>
int main()
{
    char a[5]="abcde";
    int count=0;

    printf("Entered string is:");
        
        for(int i=0;i<5;i++)

            printf("%c",a[i]);

    printf("\nReverse string is:");
       
        for(int i=sizeof(a-1);i>=0;i--)
            printf("%c",a[i]);

    printf("\nLength of string is:");
        for(int i=0;i<5;i++)
            count++; 

        printf("%d",count);
       
               

  return 0;
}