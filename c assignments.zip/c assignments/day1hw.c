#include<stdio.h>
int main()
{
    int m1,m2,m3,m4,m5;
    m1=accept();
    m2=accept();
    m3=accept();
    m4=accept();
    m5=accept();
    int totl=total(m1,m2,m3,m4,m5);
    printf("Total marks are: %d\n",totl);
    int average=avg(totl);
    printf("Average of all marks is: %d",average);
    return 0;
}

int accept()
{
    int m;
    printf("\nEnter the obtained marks: ");
    scanf("%d",&m);
    if(m>20)
        printf("Marks should not be greater than 20");
    else
        return m;    
}

int total(int a1,int a2,int a3,int a4,int a5)
{
    int total;
    total=a1+a2+a3+a4+a5;
    return total;
}
int avg(int t)
{
    int av;
    av=(t/5);
    return av;
}