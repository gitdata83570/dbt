#include<stdio.h>
int main()
{
    int m1,m2,m3,m4,m5,total;
    m1=calc();
    m2=calc();
    m3=calc();
    m4=calc();
    m5=calc();
    
    total=m1+m2+m3+m4+m5;

    if(total>=90)
    {
        printf("\n Grade: Extraordinary");
    }
    else if(total<89 && total>=80)
    { 
        printf("\n Grade: A");
    }
    else if(total<79 && total>=70)
    { 
        printf("\n Grade: B");
    }
    else if(total<69 && total>=60)
    { 
        printf("\n Grade: C");
    }
    else
    {
        printf("\nGrade: F");                
    }
    return 0;
}

int calc()
{
    int i,a,m1;
    
        printf("Enter obtained marks: ");
        scanf("%d",&a);

        if(a>20) 
            
            printf("\n Marks cant be greater than 20\n"); 
                  
        else
           
           return a;    
    
}