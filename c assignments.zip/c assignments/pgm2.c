#include<stdio.h>
int main()
{
    int a,i,fact=1;
    printf("Enter the no to calculate factorial no: ");
    scanf("%d",&a);

    for(i=1;i<=a;i++)
    {
        fact=fact*i;
    }
    printf("factorial of %d is %d\t",a,fact);
    
    return 0;

}