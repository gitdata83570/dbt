#include<stdio.h>
void accept(int arr[5]);
void display(int arr[5]);
void selection(int arr[5]);

int main()
{
    int a[5];
    accept(a);
    display(a);
    selection(a);
    return 0;
}

void accept(int arr[5])
{
    int i;
    printf("Enter array elements:");
    for(i=0;i<5;i++)
    {
        scanf("%d\t",&arr[i]);
    }
}

void display(int arr[5])
{
    int i;
    printf("\narray elements are:");
    for(i=0;i<5;i++)
    { 
        printf("%d\t",arr[i]);
    }
}

/*void selection(int arr[5])
{
    int i,swap, first,second;
    for(i=0;i<5;i++)
    {
        if(arr[i]>arr[i+1])
            swap=arr[i];
            arr[i+1]=arr[i];
    }
    printf("\nsorted array is:%d",arr[i]);
        for(i=0;i<5;i++)
            printf("\t%d",arr[i]);


}*/