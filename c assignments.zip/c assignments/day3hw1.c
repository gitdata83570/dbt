#include<stdio.h>
void accept(int arr[5]);
void display(int arr[5]);
void add(int a[5],int b[5]);
void sub(int a[5],int b[5]);
void mult(int a[5],int b[5]);
void div(int a[5],int b[5]);


int main()
{
    int a[5],b[5],c[5];
    accept(a);
    accept(b);
    display(a);
    display(b);
    add(a,b);
    sub(a,b);
    mult(a,b);
    div(a,b);
    return 0;
}

void accept(int arr[5])
{
    int i;
    printf("Enter array elements: ");
    for(i=0;i<5;i++)
        scanf("%d",&arr[i]);
}

void display(int arr[5])
{
    int i;
    printf("\narray elements are:\t");
    for(i=0;i<5;i++)
        printf("%d\t",arr[i]);
}

void add(int a[5],int b[5])
{
    int i,c[5];
   
    for(i=0;i<5;i++)
    {
        c[i]=a[i]+b[i];
    }
        printf("\nAddition of array is:\t",c[i]);
        for(i=0;i<5;i++)
            printf("%d\t",c[i]);   
}

void sub(int a[5],int b[5])
{
    int i,c[5];
    for(i=0;i<5;i++)
        c[i]=a[i]-b[i];

     printf("\nSubtraction of array is:",c[i]);
        for(i=0;i<5;i++)
            printf("%d\t",c[i]);   

}

void mult(int a[5],int b[5])
{
    int i,c[5];
    for(i=0;i<5;i++)
        c[i]=a[i]*b[i];

     printf("\nMultiplication of array is:",c[i]);
        for(i=0;i<5;i++)
            printf("%d\t",c[i]);   

}

void div(int a[5],int b[5])
{
    int i,c[5];
    for(i=0;i<5;i++)
        c[i]=a[i]/b[i];

     printf("\nDivision of array is:\t",c[i]);
        for(i=0;i<5;i++)
            printf("%d\t",c[i]);   

}