#include<stdio.h>
int main()
{   
    char ch;
    printf("Enter any char: ");
    scanf("%c",&ch);

    charref(&ch);
    return 0;
}
int charref(int *ch)
{
     if(ch>65 && ch<90)
    {
        printf("\n%c is UPPERCASE Character\n",ch);
    }
    else if(ch>97 && ch<122)
    {
        printf("\n%c is LOWERCASE character\n",ch);
    }     
    else if(ch>48 && ch<57)
    {
        printf("\n%d is a NUMBER\n",ch);
    }
    else
    {
        printf("\n%c is a Special Symbol\n",ch);        
    }
}